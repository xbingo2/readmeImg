﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using System.Text;
using System.Text.Json;

namespace MyApi.Filter
{
    /// <summary>
    /// 自定义异步请求日志过滤器（获取请求参数 + 返回结果）
    /// </summary>
    public class RequestLogAsyncFilter : IAsyncActionFilter, IAsyncResultFilter
    {
        /// <summary>
        /// Action 执行前：获取请求参数（路由、Query、Body）
        /// </summary>
        /// <param name="context">Action执行上下文（包含请求信息）</param>
        /// <param name="next">后续过滤器/Action执行委托</param>
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            // ========== 1. 获取请求基础信息 ==========
            var httpContext = context.HttpContext;
            var request = httpContext.Request;
            var requestPath = request.Path; // 请求路径
            var requestMethod = request.Method; // 请求方法（GET/POST/PUT/DELETE）
            var controllerName = context.Controller.GetType().Name; // 控制器名
            var actionName = context.ActionDescriptor.DisplayName; // Action名
            Thread.Sleep(5000);
            Console.WriteLine($"【请求开始】路径：{requestPath}，方法：{requestMethod}，控制器：{controllerName}，Action：{actionName}");

            // ========== 2. 获取路由参数 + Query 参数 ==========
            // 路由参数：context.ActionArguments 已自动封装（路由参数 + Body参数（已绑定））
            var routeAndBodyArgs = context.ActionArguments;
            Console.WriteLine($"【路由/绑定参数】：{JsonSerializer.Serialize(routeAndBodyArgs)}");

            // Query 参数：request.Query
            var queryArgs = request.Query;
            if (queryArgs.Count > 0)
            {
                var queryStr = JsonSerializer.Serialize(queryArgs.ToDictionary(kv => kv.Key, kv => kv.Value.ToString()));
                Console.WriteLine($"【Query 参数】：{queryStr}");
            }

            // ========== 3. 获取 Body 参数（POST/PUT 请求，需特殊处理流） ==========
            if (request.ContentLength > 0 && !request.Method.Equals("GET", StringComparison.OrdinalIgnoreCase))
            {
                try
                {
                    // 关键：启用流缓冲，允许多次读取（默认Request.Body只能读取一次）
                    request.EnableBuffering();

                    // 读取流数据
                    using var reader = new StreamReader(request.Body, Encoding.UTF8, leaveOpen: true);
                    var bodyContent = await reader.ReadToEndAsync();

                    // 关键：重置流位置为0，避免后续中间件/模型绑定读取失败
                    request.Body.Position = 0;

                    if (!string.IsNullOrEmpty(bodyContent))
                    {
                        Console.WriteLine($"【Body 参数】：{bodyContent}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"【获取Body参数失败】：{ex.Message}");
                }
            }

            // ========== 4. 执行后续过滤器 + Action 方法 ==========
            var resultContext = await next(); // 执行Action，返回结果上下文
        }

        /// <summary>
        /// Action 结果执行后：获取返回结果
        /// </summary>
        /// <param name="context">结果执行上下文（包含返回结果）</param>
        /// <param name="next">后续过滤器执行委托</param>
        public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
        {
            // ========== 1. 获取返回结果 ==========
            var returnResult = context.Result;
            var returnData = string.Empty;
            Thread.Sleep(5000);
            // 区分不同的返回结果类型（ObjectResult/JsonResult/ContentResult 等）
            switch (returnResult)
            {
                // 最常用：ObjectResult（API 接口返回 Ok/NotFound/BadRequest 等均为 ObjectResult 子类）
                case ObjectResult objectResult:
                    returnData = JsonSerializer.Serialize(new
                    {
                        StatusCode = objectResult.StatusCode,
                        Data = objectResult.Value
                    });
                    break;
                // JSON 结果
                case JsonResult jsonResult:
                    returnData = JsonSerializer.Serialize(jsonResult.Value);
                    break;
                // 文本结果
                case ContentResult contentResult:
                    returnData = contentResult.Content;
                    break;
                // 其他结果（如 RedirectResult 重定向）
                default:
                    returnData = returnResult.GetType().Name;
                    break;
            }

            Console.WriteLine($"【返回结果】：{returnData}");
            Console.WriteLine("【请求结束】====================================\n");

            // ========== 2. 执行后续过滤器 ==========
            await next();
        }
    }
}