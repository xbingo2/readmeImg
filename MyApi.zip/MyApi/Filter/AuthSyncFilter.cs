﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace MyApi.Filter
{
    /// <summary>
    /// 同步权限校验过滤器（验证app_key存在 + IP/app_key/请求方法一致性）
    /// </summary>
    public class AuthSyncFilter : IActionFilter
    {
       
        /// <summary>
        /// Action执行前：核心校验逻辑（优先执行，校验失败终止请求）
        /// </summary>
        /// <param name="context">Action执行上下文</param>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                // ========== 步骤1：获取请求上下文核心信息 ==========
                var httpContext = context.HttpContext;
                var request = httpContext.Request;
                var requestMethod = request.Method.ToUpper(); // 当前请求方法（转大写，统一匹配）
                var remoteIp = GetClientRealIp(httpContext); // 获取客户端真实IP

                // ========== 步骤2：校验是否存在app_key参数 ==========
                // 优先从Header获取（推荐：Header传递更安全），再从Query参数获取（兼容URL拼接）
                string? appKey = request.Headers["app_key"].FirstOrDefault() ?? request.Query["app_key"].FirstOrDefault();

                // app_key为空，直接返回400错误（参数缺失）
                if (string.IsNullOrEmpty(appKey))
                {
                    context.Result = new BadRequestObjectResult(new
                    {
                        Code = 400,
                        Msg = "请求参数缺失：必须携带app_key参数（Header或Query均可）",
                        Data = ""
                    });
                    return; // 终止后续逻辑执行
                }

                // ========== 步骤3：查询数据库，获取app_key对应的权限配置 ==========
                // 同步查询：获取启用状态的app_key配置（EF Core同步查询，无await）
                var appPermission = "";/*_dbContext.AppPermissions
                    .Where(p => p.AppKey == appKey && p.IsEnabled == true)
                    .FirstOrDefault();*/

                // app_key不存在或已禁用，返回401未授权
                if (appPermission == null)
                {
                    context.Result = new UnauthorizedObjectResult(new
                    {
                        Code = 401,
                        Msg = "未授权：无效的app_key或该应用已禁用",
                        Data = ""
                    });
                    return;
                }

                // ========== 步骤4：验证IP是否在允许范围内 ==========
                // 分割允许的IP列表（多个IP用英文逗号分隔）
               /* var allowIpList = appPermission.AllowIp.Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(ip => ip.Trim().ToUpper())
                    .ToList();*/
                // 当前IP不在允许列表中，返回403禁止访问
              /*  if (!allowIpList.Contains(remoteIp.ToUpper()))
                {
                    context.Result = new ForbidResult(new ObjectResult(new
                    {
                        Code = 403,
                        Msg = $"IP禁止访问：当前IP({remoteIp})不在该app_key的允许IP列表中",
                        Data = ""
                    }));
                    return;
                }*/

                // ========== 步骤5：验证请求方法是否在允许范围内 ==========
                // 分割允许的请求方法列表（多个方法用英文逗号分隔）
               /* var allowMethodList = appPermission.AllowMethod.Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(method => method.Trim().ToUpper())
                    .ToList();
                // 当前请求方法不在允许列表中，返回403禁止访问
                if (!allowMethodList.Contains(requestMethod))
                {
                    context.Result = new ForbidResult(new ObjectResult(new
                    {
                        Code = 403,
                        Msg = $"请求方法不允许：当前方法({requestMethod})不在该app_key的允许方法列表中",
                        Data = null
                    }));
                    return;
                }*/

                // ========== 所有校验通过：继续执行后续Action逻辑 ==========
                Console.WriteLine($"【权限校验通过】app_key：{appKey}，IP：{remoteIp}，请求方法：{requestMethod}");
            }
            catch (Exception ex)
            {
                // 异常处理：数据库查询失败等情况，返回500服务器错误
                context.Result = new ObjectResult(new
                {
                    Code = 500,
                    Msg = $"权限校验异常：{ex.Message}",
                    Data = ""
                })
                {
                    StatusCode = 500
                };
                Console.WriteLine($"【权限校验异常】：{ex.Message}");
            }
        }

        /// <summary>
        /// Action执行后：无需处理（仅校验前置逻辑，此方法留空即可）
        /// </summary>
        /// <param name="context">Action执行完成上下文</param>
        public void OnActionExecuted(ActionExecutedContext context)
        {
            // 可选：可在此处记录Action执行后的状态（如是否异常）
            if (context.Exception != null)
            {
                Console.WriteLine($"【Action执行异常】：{context.Exception.Message}");
                // 若需处理异常，可设置 context.ExceptionHandled = true;
            }
        }

        /// <summary>
        /// 获取客户端真实IP（兼容反向代理/Nginx部署场景）
        /// </summary>
        /// <param name="httpContext">Http上下文</param>
        /// <returns>客户端真实IP</returns>
        private string GetClientRealIp(HttpContext httpContext)
        {
            // 优先从X-Forwarded-For头获取（反向代理场景：Nginx/Apache等）
            var forwardedIp = httpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
            if (!string.IsNullOrEmpty(forwardedIp))
            {
                // X-Forwarded-For格式：客户端IP, 代理IP1, 代理IP2... 取第一个即为真实客户端IP
                return forwardedIp.Split(',')[0].Trim();
            }

            // 无反向代理时，直接获取远程IP（本地调试为：127.0.0.1/::1）
            return httpContext.Connection.RemoteIpAddress?.ToString() ?? "未知IP";
        }
    }
}