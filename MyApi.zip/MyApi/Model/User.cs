﻿namespace MyApi.Model
{
    using SqlSugar;

    [SugarTable("T_USER")]
    public class User
    {
        [SugarColumn(ColumnName = "ID", IsPrimaryKey = true)]
        public long Id { get; set; }

        [SugarColumn(ColumnName = "USER_NAME", Length = 50)]
        public string UserName { get; set; }

        [SugarColumn(ColumnName = "AGE")]
        public int Age { get; set; }
    }
}
