﻿namespace MyApi.Model
{
    using SqlSugar;

    [SugarTable("API_LOG")]
    public class ApiLog
    {
        [SugarColumn(ColumnName = "ID", IsPrimaryKey = true, IsIdentity = true)]
        public long Id { get; set; }

        [SugarColumn(ColumnName = "LOG_TYPE", Length = 20)] // IN/OUT/ERROR
        public string LogType { get; set; }

        [SugarColumn(ColumnName = "METHOD_NAME", Length = 100)]
        public string MethodName { get; set; }

        [SugarColumn(ColumnName = "PATH", Length = 200)]
        public string Path { get; set; }

        [SugarColumn(ColumnName = "REQUEST_PARAMS")]
        public string RequestParams { get; set; }

        [SugarColumn(ColumnName = "RESPONSE_DATA")]
        public string ResponseData { get; set; }

        [SugarColumn(ColumnName = "ELAPSED_TIME")]
        public long ElapsedTime { get; set; }

        [SugarColumn(ColumnName = "CREATE_TIME")]
        public DateTime CreateTime { get; set; } = DateTime.Now;
    }
}
