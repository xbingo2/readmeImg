using Microsoft.AspNetCore.Mvc;
using SqlSugar;

namespace MyApi.Controllers
{
    //[TypeFilter(typeof(RequestLogAsyncFilter))]
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {

        private readonly ISqlSugarClient _sqlSugarClient;

        public WeatherForecastController(ISqlSugarClient sqlSugarClient)
        {
            _sqlSugarClient = sqlSugarClient;
        }

        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

         

        [HttpPost(Name = "GetWeatherForecast")]
        public IEnumerable<WeatherForecast> Get()
        {

           // var businessDb = _sqlSugarClient.GetConnection("");// ҵ�������
           // var orderDb = _sqlSugarClient.GetConnection("Db_Order");       // ����������
            //var userDb = _sqlSugarClient.GetConnection("Db_User");         // �û�������

            // ��֤�����Ƿ����
           /* if (businessDb == null || orderDb == null || userDb == null)
            {
                return BadRequest(new { Code = 400, Message = "ָ�����ݿ����Ӳ����ڣ����� ConfigId" });
            }*/




            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();
        }
    }
}
